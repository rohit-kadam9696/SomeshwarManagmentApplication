import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

class AuthenticatePage extends StatefulWidget {
  @override
  _AuthenticatePageState createState() => _AuthenticatePageState();
}

class _AuthenticatePageState extends State<AuthenticatePage> {
  TextEditingController _pinController = TextEditingController();
  final LocalAuthentication _localAuthentication = LocalAuthentication();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Authenticate'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            margin: EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _pinController,
                  decoration: InputDecoration(
                    hintText: 'Enter PIN',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  obscureText: true,
                ),
                SizedBox(height: 16.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      'Forgot PIN',
                      style: TextStyle(fontSize: 12.0),
                    ),
                    SizedBox(width: 8.0),
                    Text(
                      '|',
                      style: TextStyle(fontSize: 12.0),
                    ),
                    SizedBox(width: 8.0),
                    Text(
                      'Change PIN',
                      style: TextStyle(fontSize: 12.0),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 16.0),
                  child: Column(
                    children: [
                      SizedBox(
                        width: 120.0,
                        height: 120.0,
                        child: FloatingActionButton(
                          onPressed: () async {
                            // Call startAuth method of FingerprintHandler
                            await FingerprintHandler(context).startAuth(_localAuthentication);
                          },
                          child: Icon(
                            Icons.fingerprint,
                            size: 60.0,
                          ),
                        ),
                      ),
                      SizedBox(height: 16.0),
                      Text(
                        'Touch ID Authentication',
                        style: TextStyle(
                          fontSize: 20.0,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(height: 8.0),
                      Text(
                        'Use your fingerprint to authenticate.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 16.0),
                      ),
                      SizedBox(height: 30.0),
                      Text(
                        'Error Message Here',
                        style: TextStyle(color: Colors.red, fontSize: 14.0),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.all(16.0),
            child: Text(
              'Note: Additional note text here.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14.0),
            ),
          ),
        ],
      ),
    );
  }
}

class FingerprintHandler {
  final BuildContext context;

  FingerprintHandler(this.context);

  Future<void> startAuth(LocalAuthentication localAuth) async {
    try {
      bool authenticated = await localAuth.authenticate(
        localizedReason: 'Authenticate to proceed',
        //useErrorDialogs: true, // Add this parameter
      );
      if (authenticated) {
        Navigator.pushReplacementNamed(context, '/home');
      }
    } on PlatformException catch (e) {
      update("Fingerprint Authentication error\n${e.message}");
    }
  }

  void update(String e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(e),
      ),
    );
  }
}
