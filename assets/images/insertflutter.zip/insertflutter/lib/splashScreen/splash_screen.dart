import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:device_info/device_info.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:insertflutter/appInfo/app_info.dart';
import 'package:insertflutter/ui/authnticate.dart';
import 'package:insertflutter/ui/change_pin_activity.dart';
import 'package:insertflutter/ui/home_page.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../SharedPrefrence/shared_pref.dart';
import '../SharedPrefrence/shared_pref2.dart';
import '../ui/bottom_nav_activity.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with WidgetsBindingObserver{
  bool _loggedIn = false;
  static String identifier = 'Identifier not available';
  String chitBoyId = '';
  String uniqstring = '';
  String mobileNo = '';
  String imei = '';
  String pin='';

  @override
  void initState() {
    super.initState();
    _loadSharedPreferences();
    _getDeviceInfo();
    WidgetsBinding.instance!.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance!.removeObserver(this);
    super.dispose();
  }
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkLoggedInStatus(context);
    }
  }
  Future<void> _loadSharedPreferences() async {
    chitBoyId = await SharedPreferencesHelper.getChitboyId();
    uniqstring = await SharedPreferencesHelper.getUniqString();
    mobileNo = await SharedPreferencesHelper.getMobileNo();
    imei = await SharedPreferencesHelper.getImei();
    pin= await SharedPreferencesHelper.getLoginPin();
    String version = await AppInfo.getVersionId();
    setState(() {
      // Update the state variables with the obtained values
      chitBoyId = chitBoyId;
      uniqstring = uniqstring;
      mobileNo = mobileNo;
      imei = imei;
      pin=pin;
    });
    await Future.delayed(Duration(seconds: 3));
    await _checkLoggedInStatus(context);
  }

  Future<void> _checkLoggedInStatus(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? mobileNo = prefs.getString('flutter.flutter.mobileNo');
    String? pin =   prefs.getString('lutter.loginPin');

    // if (pin == null) {
    //   // PIN is null, navigate to a page for PIN setup
    //   Navigator.pushReplacement(
    //     context,
    //     MaterialPageRoute(builder: (context) => ChangePinActivity()),
    //   );
    // } else if (mobileNo == null || mobileNo.isEmpty) {
    //   // Mobile number is null or empty, navigate to HomePage
    //   Navigator.pushReplacement(
    //     context,
    //     MaterialPageRoute(builder: (context) => HomePage()),
    //   );
    // } else {
    //   // Mobile number is not null or empty and PIN is not null, user is logged in, navigate to BottomNav
    //   setState(() {
    //     _loggedIn = true;
    //   });
    //   Navigator.pushReplacement(
    //     context,
    //     MaterialPageRoute(builder: (context) => BottomNav()),
    //   );
    // }

    if (mobileNo != null && mobileNo.isNotEmpty) {
      setState(() {
        _loggedIn = true;
      });
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => BottomNav()),);
    }
    else {
      // User has not logged in before
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => AuthenticatePage()),
      );
    }
  }



  Future<void> _getDeviceInfo() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var status = await Permission.phone.status;
        if (status.isGranted) {
          AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
          String imei = androidInfo.androidId ?? 'IMEI not available';
          setState(() {
            identifier = imei;
          });
        } else {
          await Permission.phone.request();
        }
      } else if (Platform.isIOS) {
        IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
        identifier = iosInfo.identifierForVendor ?? 'Identifier not available';
        setState(() {
          identifier = identifier;
        });
      }
    } catch (e) {
      print('Error getting device info: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    // Your splash screen UI
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: 200, // Set the desired width
              height: 200, // Set the desired height
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.black87, // Set the border color
                  width: 4, // Set the border width
                ),
              ),
              child: ClipOval(
                child: Image.asset(
                  'lib/splashScreenImage/ic_launcher.png', // Adjust the path accordingly
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
