import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Widgets/vikri_satha_by_date.dart';

class VikriSathaPage extends StatefulWidget {
  const VikriSathaPage({super.key});

  @override
  State<VikriSathaPage> createState() => _VikriSathaPageState();
}

class _VikriSathaPageState extends State<VikriSathaPage> {
  static Color currentSection = const Color(0x626262);
  static Color aBackground = const Color(0xE5E5E5);
  static Color aSidebar = const Color(0x7C01FF);
  static Color aSoundButton = const Color(0xA93EF0);
  static Color aSoundLockedButton = const Color(0x555555);
  static Color lightRed = const Color(0xFFFFCDD2);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              height: 10,
            ),
            VikriSathaWidget(),
          ],
        ),
      ),
    );
  }

}
