import 'package:flutter/material.dart';
import 'package:insertflutter/splashScreen/splash_screen.dart';
import 'package:insertflutter/ui/authnticate.dart';
import 'package:insertflutter/ui/bottom_nav_activity.dart';
import 'package:insertflutter/ui/home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';


void main() {
  runApp(const MyApp());
}
class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  bool _loggedIn = false;

  @override
  void initState() {
    super.initState();
    _checkLoggedInStatus();
  }

  Future<void> _checkLoggedInStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? mobileNo = prefs.getString('flutter.mobileNo');
    if (mobileNo != null && mobileNo.isNotEmpty) {
      setState(() {
        _loggedIn = true; // Update _loggedIn if user is logged in
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => SplashScreen(), // Set SplashScreen as the initial route
        '/auth': (context) => AuthenticatePage(), // Add a route for authentication
       '/bottomNav': (context) => _loggedIn ? BottomNav() : HomePage(),
        '/home': (context) => HomePage(), // Add a route for the home screen
      },
    //   initialRoute: '/',
    //   routes: {
    //     '/': (context) => SplashScreen(), // Set SplashScreen as the initial route
    //     '/bottomNav': (context) => _loggedIn ? BottomNav() : HomePage(),
    //     '/home': (context) => HomePage(), // Add a route for the login screen
    //   },
     );
  }
}

