// import 'dart:convert';
//
// import '../pojo/crushing_report.dart';
// import 'package:http/http.dart' as http;
//
// import '../setStateWidget/setState.dart';
// class ApiResponse{
//   Future<CrushingReport?> crushingReport1(String randomString, String chitBoyId,
//       String imei, String versionId, String date, String mobileNo,
//       String YearCode) async {
//     print("hii hello $randomString");
//     print("hii hello $chitBoyId");
//     print("hii hello $imei");
//     print("hii hello $versionId");
//     print("hii hello $date");
//     print("hii hello $mobileNo");
//     print("hii hello $YearCode");
//     try {
//       String uri = "http://117.205.2.18:8082/FlutterMIS/Reportcontroller";
//       Map<String, dynamic> requestBody = {
//         'action': "crushingreport",
//         'mobileNo': mobileNo,
//         'imei': imei,
//         'randomString': randomString,
//         'versionId': versionId,
//         'chitBoyId': chitBoyId,
//         'date': date,
//         'YearCode': YearCode,
//       };
//       String json = jsonEncode(requestBody);
//       var res = await http.post(
//         Uri.parse(uri),
//         body: json,
//         headers: {'Content-Type': 'application/json'},
//       );
//       if (res.statusCode == 200) {
//         var jsondecode = jsonDecode(res.body);
//
//
//         if (jsondecode is Map<String, dynamic> &&
//             jsondecode.containsKey("success") &&
//             jsondecode["success"] == true) {
//
//             CrushingReport updatedReport = CrushingReport.fromJson(jsondecode);
//             ApiState.
//             _updateState(updatedReport);
//             CrushingReport.fromJson(jsondecode);
//
//           return CrushingReport.fromJson(jsondecode);
//         } else {
//           print('Error: Unexpected response format');
//         }
//       } else {
//         print('Error: ${res.statusCode}');
//       }
//     } catch (error) {
//       print('Error: $error');
//     }
//
//
//     return null;
//   }
//
//
//
// }