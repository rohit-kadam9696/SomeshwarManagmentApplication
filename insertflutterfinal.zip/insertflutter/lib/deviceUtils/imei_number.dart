
class DeviceInformation{

}