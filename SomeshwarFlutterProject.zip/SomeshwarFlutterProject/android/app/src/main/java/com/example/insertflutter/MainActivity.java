package com.example.insertflutter;



import io.flutter.embedding.android.FlutterFragmentActivity;


public class MainActivity extends FlutterFragmentActivity {
}
