import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../Widgets/pudil_us_nond.dart';

class PunarUsNodPage extends StatefulWidget {
  const PunarUsNodPage({super.key});

  @override
  State<PunarUsNodPage> createState() => _PunarUsNodPageState();
}

class _PunarUsNodPageState extends State<PunarUsNodPage> {

  static const Color brownColor = Color(0xFF8B4513);
  static Color darkBlue = const Color(0xFF03A9F4);
  static Color smalldarkBlue = const Color(0xFFBBDEFB);
  static Color verysmalldarkBlue = const Color(0xFFE3F2FD);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            SizedBox(
              height: 10,
            ),
            PudilUsNond(),
          ],
        ),
      ),
    );
  }
}
