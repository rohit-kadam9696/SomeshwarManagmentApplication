import 'package:flutter/material.dart';
import 'package:SomeshwarInternalApp/splashScreen/splash_screen.dart';
import 'package:SomeshwarInternalApp/ui/authnticate2.dart';
import 'package:SomeshwarInternalApp/ui/bottom_nav_activity.dart';
import 'package:SomeshwarInternalApp/ui/change_pin_activity.dart';
import 'package:SomeshwarInternalApp/ui/home_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
void main(){
  runApp(const MyApp());
}
class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  late Future<void> _checkLoginFuture=Future.value();
  bool _loggedIn = false;
  String ? pin;

  @override
  void initState() {
    super.initState();
    _checkLoginFuture = _checkLoggedInStatus();
  }
  Future<void> _checkLoggedInStatus() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? mobileNo = prefs.getString('flutter.mobileNo');
    String? pin = prefs.getString('flutter.loginPin');
    if (mobileNo != null && mobileNo.isNotEmpty) {
      setState(() {
        _loggedIn = true;
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: FutureBuilder<void>(
        future: _checkLoginFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return _loggedIn ? SplashScreen() : HomePage();
          } else {
            return Scaffold(body: Center(child: CircularProgressIndicator(color: Colors.blue,)));
          }
        },
      ),
      routes: {
        '/auth': (context) => _loggedIn ? AuthenticateController() : HomePage(),
        '/home': (context) => HomePage(),
        '/loginPin': (context) => ChangePinActivity(),
        '/authenticate': (context) => _loggedIn ? AuthenticateController() : SplashScreen(),
        '/bottomNav': (context) => BottomNav(),
        '/changePin': (context) => _loggedIn && (pin == null || pin!.isEmpty) ? ChangePinActivity() : AuthenticateController(),
      },
    );
  }
}
