import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:SomeshwarInternalApp/Widgets/chalu_us_nond.dart';
class ChaUsNodPage extends StatefulWidget {
  const ChaUsNodPage({super.key});

  @override
  State<ChaUsNodPage> createState() => _ChaUsNodPageState();
}

class _ChaUsNodPageState extends State<ChaUsNodPage> {
  static Color currentSection = const Color(0x626262);
  static Color aBackground = const Color(0xE5E5E5);
  static Color aSidebar = const Color(0x7C01FF);
  static Color aSoundButton = const Color(0xA93EF0);
  static Color aSoundLockedButton = const Color(0x555555);
  static Color lightRed = const Color(0xFFFFCDD2);
  static Color darkyellow = const Color(0xFFF5E54F);
  static Color smallyellow = const Color(0xFFFFF176);
  static Color verysmallyellow = const Color(0xFFFFF59D);
  static const Color brownColor = Color(0xFF8B4513);


    @override
    Widget build(BuildContext context) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SizedBox(
                height: 10,
              ),
              ChaluUsNondWidget(),
            ],
          ),
        ),
      );
    }


  }
