import 'dart:convert';

import 'package:connectivity/connectivity.dart';
import 'package:device_info/device_info.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:convert' as convert;

import 'package:http/http.dart' as http;

import 'package:device_info/device_info.dart';

import 'package:insertflutter/pojo/login_response.dart';
import 'package:insertflutter/pojo/main_response.dart';
import 'package:insertflutter/ui/otp_activity.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../SharedPrefrence/shared_pref.dart';
import '../SharedPrefrence/shared_pref2.dart';
import '../appInfo/app_info.dart';
import '../constant/random_string.dart';
import '../constant/snackbar_apierror.dart';
import '../constantfunction/constant_function.dart';
import '../progress_bar/progress_bar.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  LoginResponse loginResponse = LoginResponse();
  MainResponse mainResponse = MainResponse();

  List<String> key = ['chitBoyId', 'uniquestring'];
  List<String> value = ['', '0'];
  static String identifier = 'Identifier not available';
  TextEditingController mobileno = TextEditingController();

  @override
  void initState() {
    super.initState();
    _getDeviceInfo();
  }


Future<void> saveChitBoyIdToPrefs(String ? chitBoyId) async {
    if (chitBoyId != null) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('chitBoyId', chitBoyId);
    } else {
      // Handle the case where chitBoyId is null, if needed
      print("chitBoyId is null. Cannot save to SharedPreferences.");
    }
  }
  Future<void> saveRandomStringToPref(String ? randomString) async {
    // SharedPreferences prefs = await SharedPreferences.getInstance();
    // await prefs.setString('randomString', randomString);
    if (randomString != null) {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      await prefs.setString('randomString', randomString);
    } else {
      // Handle the case where chitBoyId is null, if needed
      print("randomString is null. Cannot save to SharedPreferences.");
    }
  }

  Future<String?> getChitBoyIdFromPrefs() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('chitBoyId');
  }
  Future<void> saveMobileNo(String mobileno) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString('mobileNo', mobileno);
  }



  Future<void> _getDeviceInfo() async {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

    try {
      if (Platform.isAndroid) {
        var status = await Permission.phone.status;
        if (status.isGranted) {
          AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
          String imei = androidInfo.androidId ?? 'IMEI not available';
          setState(() {
            identifier = imei;
          });
        } else {
          await Permission.phone.request();
        }
      } else if (Platform.isIOS) {
        IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
        identifier = iosInfo.identifierForVendor ?? 'Identifier not available';
        setState(() {
          identifier = identifier;
        });
      }
    } catch (e) {
      print('Error getting device info: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: OrientationBuilder(
        builder: (context, orientation) {
          return Stack(
            children: [
              Image.asset(
                "assets/images/someshwarnew.jpg",
                fit: BoxFit.cover,
                width: double.infinity,
                height: double.infinity,
              ),
              Positioned.fill(
                child: Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                    width: MediaQuery
                        .of(context)
                        .size
                        .width * 1,
                    // height: orientation == Orientation.portrait ? 400 : 300,
                    height: 400,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: Colors.white,
                      elevation: 5,
                      margin: EdgeInsets.all(20),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: ListView(
                          children: [
                            Container(
                              margin: EdgeInsets.all(10),
                              child: Text(
                                'लॉग इन ',
                                maxLines: 3,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w800,
                                  fontStyle: FontStyle.normal,
                                  fontFamily: 'Open Sans',
                                  fontSize: 30,
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                border: Border.all(
                                  color: Colors.green,
                                  // Change the border color as needed
                                  width: 2.0, // Adjust the border width
                                ),
                                borderRadius: BorderRadius.circular(
                                    10), // Adjust the border radius
                              ),
                              child: TextFormField(
                                keyboardType: TextInputType.phone,
                                controller: mobileno,
                                decoration: InputDecoration(
                                  contentPadding: EdgeInsets.symmetric(
                                      vertical: 15, horizontal: 10),
                                  labelText: "Enter mobile no",
                                  hintText: "मोबाइल क्रमांक",
                                  border: InputBorder
                                      .none, // Remove the default border
                                ),
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.all(10),
                              child: TextButton(


                                onPressed: () async {
                                  String phoneno = mobileno.text;
                                  if (phoneno.isEmpty) {
                                    double height = 220.0;
                                    String mobileNoEmptyMsg = "कृपया मोबाइल क्रमांक टाका.";
                                    print("Please Enter Mobile Number");
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Container(
                                          padding: EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius: BorderRadius.circular(
                                                10), // Adjust the border radius
                                            border: Border.all(
                                              color: Colors.greenAccent,
                                              // Adjust the border color
                                              width: 2.0, // Adjust the border width
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 40),
                                            child: Text(
                                              "कृपया मोबाइल क्रमांक टाका.",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                              ),
                                            ),
                                          ),
                                        ),
                                        duration: Duration(seconds: 3),
                                        backgroundColor: Colors.transparent,
                                      ),
                                    );
                                  }
                                  else if (phoneno.length < 10) {
                                    ScaffoldMessenger.of(context).showSnackBar(

                                      SnackBar(
                                        content: Container(
                                          padding: EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius: BorderRadius.circular(
                                                10), // Adjust the border radius
                                            border: Border.all(
                                              color: Colors.greenAccent,
                                              // Adjust the border color
                                              width: 2.0, // Adjust the border width
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 40),
                                            child: Text(
                                              "फोन नंबर चुकीचा आहे.",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                              ),
                                            ),
                                          ),
                                        ),
                                        duration: Duration(seconds: 3),
                                        backgroundColor: Colors.transparent,
                                      ),
                                    );
                                  } else if (phoneno.length > 12) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Container(
                                          padding: EdgeInsets.all(16),
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius: BorderRadius.circular(
                                                10), // Adjust the border radius
                                            border: Border.all(
                                              color: Colors.greenAccent,
                                              // Adjust the border color
                                              width: 2.0, // Adjust the border width
                                            ),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                left: 40),
                                            child: Text(
                                              "फोन नंबर चुकीचा आहे.",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 20,
                                              ),
                                            ),
                                          ),
                                        ),
                                        duration: Duration(seconds: 3),
                                        backgroundColor: Colors.transparent,
                                      ),
                                    );
                                  }
                                  else {
                                    ProgressDialog.loadProgressDialog(context);
                                    await _getDeviceInfo();
                                    String versionId = await AppInfo
                                        .getVersionId();

                                    // ConstantFunction cf = ConstantFunction();
                                    // List<String> data = await cf.putSharedPrefValue(key, value);

                                    saveMobileNo(phoneno);
                                    String chitBoyId = "";
                                    String randomString = "";
                                    doLogin(phoneno, identifier, randomString,
                                        versionId, chitBoyId);
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => HomePage()),
                                    );
                                  }
                                },
                                child: Text(
                                  'लॉग इन',
                                  style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.white,
                                  ),
                                ),
                                style: TextButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 20,
                                    vertical: 5,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
  Future<void> doLogin(String mobileno, String imei, String randomString, String versionId, String chitBoyId) async {
    if (mobileno.isNotEmpty) {
      try {
        var connectivityResult = await Connectivity().checkConnectivity();
        if (connectivityResult == ConnectivityResult.none) {
          print("No internet connectivity");
          return;
        }

        String uri = "http://117.205.2.18:8082/FlutterMIS/app_login";
        Map<String, dynamic> requestBody = {
          'action': "Login",
          'mobileno': mobileno,
          'imei': imei,
          'randomString': randomString,
          'versionId': versionId,
          'chitBoyId': chitBoyId,
        };

        String json = jsonEncode(requestBody);
        var res = await http.post(
          Uri.parse(uri),
          body: json,
          headers: {'Content-Type': 'application/json'},
        );
        double customHeight = 220.0;
        if (res.statusCode == 200) {
          var jsondecode = jsonDecode(res.body);
          if (jsondecode.containsKey("success") && jsondecode["success"] == true) {
            String chitBoyId = jsondecode["chitBoyId"];
            String randomString = jsondecode["uniquestring"];
            String mobileno = jsondecode["mobileno"];

            // Store values in shared preferences
            await SharedPreferencesHelper.storeValuesInSharedPref(chitBoyId, randomString, mobileno, imei);

            // Retrieve stored values from shared preferences
            String storedMobileNo = await SharedPreferencesHelper.getMobileNo();
            String oldPin = await SharedPreferencesHelper.getLoginPin();

            // Update the state with the obtained values
            setState(() {
              storedMobileNo = storedMobileNo;
              oldPin = oldPin;
            });

            // Navigate to the next screen
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => OtpActivity(
                  imei: imei,
                  randomString: randomString,
                  versionId: versionId,
                  chitBoyId: chitBoyId,
                ),
              ),
            );
          } else {
            String servererrormsg = jsondecode['se']['msg'];
            SnackbarHelper.showSnackbar(
              context,
              msg: servererrormsg,
              height: customHeight,
            );
          }
        } else {
          // Handle other status codes or errors
          print('Error: ${res.statusCode}');
        }
      } catch (error) {
        print('Error: $error');
      }
    } else {
      print("Please Fill All Details");
    }
  }

//   Future<void> doLogin(String mobileno, String imei, String randomString,
//       String versionId, String chitBoyId) async {
// // List<String> data
//     if (mobileno.isNotEmpty) {
//       try {
//         var connectivityResult = await Connectivity().checkConnectivity();
//
//         if (connectivityResult == ConnectivityResult.none) {
//           print("No internet connectivity");
//           return;
//         }
// //117.205.2.18
//         String uri = "http://117.205.2.18:8082/FlutterMIS/app_login";
//         Map<String, dynamic> requestBody = {
//           'action': "Login",
//           'mobileno': mobileno,
//           'imei': imei,
//           'randomString': randomString,
//           'versionId': versionId,
//           //'data': data,
//           'chitBoyId': chitBoyId,
//         };
//
//         String json = jsonEncode(requestBody);
//         var res = await http.post(
//           Uri.parse(uri),
//           body: json,
//           headers: {'Content-Type': 'application/json'},
//         );
//
//         double customHeight = 220.0;
//
//         if (res.statusCode == 200) {
//           var jsondecode = jsonDecode(res.body);
//
//
//           if (jsondecode.containsKey("success") &&
//               jsondecode["success"] == true) {
//             String chitBoyId = jsondecode["chitBoyId"];
//             String randomString = jsondecode["uniquestring"];
//             String mobileno = jsondecode["mobileno"];
//
//             ConstantFunction cf = new ConstantFunction();
//             setState(() async {
//               // PreferencesHelper.storeValuesInSharedPreferences(
//               //     chitBoyId, randomString, mobileno, imei);
//               // PreferencesHelper.getStoredMobileNo();
//               // PreferencesHelper.getOldPinFromSharedPreferences();
//                SharedPreferencesHelper.storeValuesInSharedPref(chitBoyId, randomString, mobileno, imei);
//
//                String storedMobileNo = await SharedPreferencesHelper.getMobileNo();
//                print('Stored Mobile Number: $storedMobileNo');
//
//                // Retrieve old PIN from SharedPreferences
//                String oldPin = await SharedPreferencesHelper.getLoginPin();
//                print('Old PIN: $oldPin');
//
//                storedMobileNo = storedMobileNo;
//                oldPin = oldPin;
//             });
//
//             print("JSONRESPONSE:==> $jsondecode");
//             try {
//               Navigator.of(context).push(
//                 MaterialPageRoute(
//                   builder: (context) =>
//                       OtpActivity(
//                         imei: imei,
//                         randomString: randomString,
//                         versionId: versionId,
//                         chitBoyId: chitBoyId,
//                       ),
//                 ),
//               );
//             } catch (e, s) {
//               print(s);
//             }
//           } else {
//             String servererrormsg = jsondecode['se']['msg'];
//             SnackbarHelper.showSnackbar(
//               context,
//               msg: servererrormsg,
//               height: customHeight,
//             );
//           }
//         } else {
//           // Handle other status codes or errors
//           print('Error: ${res.statusCode}');
//         }
//       } catch (error) {
//         print('Error: $error');
//       }
//     } else {
//       print("Please Fill All Details");
//     }
//   }


}






