
import 'package:flutter/material.dart';

import '../Widgets/vikri_satha_by_date.dart';

class VikriSathaPage extends StatefulWidget {
  const VikriSathaPage({super.key});

  @override
  State<VikriSathaPage> createState() => _VikriSathaPageState();
}

class _VikriSathaPageState extends State<VikriSathaPage> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
      body:  SingleChildScrollView(
        child:  Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children:  <Widget>[
            SizedBox(
              height: 10,
            ),
             VikriSathaWidget(),
          ],
        ),
      ),
    );
  }

}
